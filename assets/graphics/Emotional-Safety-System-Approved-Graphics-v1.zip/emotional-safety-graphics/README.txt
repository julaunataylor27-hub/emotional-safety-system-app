EMOTIONAL SAFETY SYSTEM — APPROVED GRAPHICS V1

masters/ = exact approved PNG generations
app/ = mobile-optimised WebP copies for GitHub / React Native

Approved set:
1. australia-code-art-v1
2. humanity-hero-v1
3. knowledge-justice-v1
4. primary-riders-v1
5. riders-crest-v1

Do not replace the current live app assets until the new files have been committed and the APK smoke test passes.
